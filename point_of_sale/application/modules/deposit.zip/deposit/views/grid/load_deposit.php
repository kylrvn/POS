<?php
$session = (object)get_userdata(USER);

if (!empty($result)) {
    foreach ($result as $key => $value) {
        ?>
            <tr>
                <td><?= $key+1 ?></td>
                <td><?= date('M d, Y', strtotime(@$value->Date)) ?></td>
                <td class="text-wrap"><?= number_format(@$value->Cash,2)?></td>
                <td class="text-wrap"><?= ucfirst(@$value->Mode) ?></td>
                <td class="text-wrap"><?= ucfirst(@$value->Notes) ?></td>
                <td class="text-wrap"><?= ucfirst($value->FName." ".@$value->LName."(".@$value->Branch.")") ?></td>
                <td>
                    <button class=" btn-danger btn-xs delete" value="<?=$value->ID?>"><i class="fa fa-trash-alt"></i></button>
                    <button class=" btn-primary btn-xs view_image" value="<?=$value->Proof?>"><i class="fa fa-eye"></i></button>
                </td>
            </tr>

        <?php
    } ?>

<?php } else { ?>
    <tr>
        <td colspan="8">
            <div>
                <center>
                    <h6>No data available in table.</h6>
                </center>
            </div>
        </td>
    </tr>
<?php }
?>